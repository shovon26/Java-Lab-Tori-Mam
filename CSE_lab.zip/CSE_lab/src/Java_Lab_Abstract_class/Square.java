package Java_Lab_Abstract_class;

public class Square extends Rectangle{
	public Square(double len) {
		super(len,len);
		// TODO Auto-generated constructor stub
	}
	
	void setlength(double length)
	{
		super.setHeight(length);
		super.setWidth(length);
	}
   
	double getlength()
	{
		
		return super.getHeight();
	}
	
	public void computeArea()
	{
		super.setArea(super.getHeight()*super.getWidth());
	}
	
	public void displayShape()
	{
		
		System.out.println("Height=  "+height+ "   Width = "+width);
		System.out.println("Area of Square = "+super.GetArea());
	}
}
