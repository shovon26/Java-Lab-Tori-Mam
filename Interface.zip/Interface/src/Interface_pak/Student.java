package Interface_pak;


public class Student implements StInterfacee {
	
	String name;
	int id,idd;
	String address;
	
	public void setAddress(String ss)
	{
		address=ss;
	}
	
	public void setName(String s) {
		name=s;
	}
	public void setID(int ii)
	{
		id=ii;
	}
	
	public String getName()
	{
		return name;
	}
	public int getID()
	{
		return id;
	}
	
	public String getaddress()
	{
		return address;
	}

} 
