package Java_Lab_Abstract_class;


public class Rectangle extends GeometryShape {
	
	double height,width,A;
	public  Rectangle(double x,double y) {
		
		this.height=x;
		this.width=y;
	}
    
	 public void setHeight(double height) {
		this.height = height;
	}
	 
	 public void setWidth(double width) {
		this.width = width;
	}
	 
	 public double getHeight() {
		return height;
	}
	
	 public double getWidth() {
		return width;
	}
	
	@Override
	public void computeArea() {
		A=height*width;
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayShape() {
		// TODO Auto-generated method stub
		
		System.out.println("Height=  "+height+ "   Width = "+width);
		System.out.println("Area of Rectangle = "+A);
	}

}
