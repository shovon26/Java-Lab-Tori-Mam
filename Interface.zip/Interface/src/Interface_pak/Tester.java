package Interface_pak;
import java.util.Scanner;
public class Tester {
  public static void main(String[] args) {
	
	  Student[] ob=new Student[4];
	  
	  int i,j,k;
	  Scanner in=new Scanner(System.in);
	  
	  String name,add;
	  int id;
	  
	  System.out.println("Enter Info");
	  for(i=0;i<2;i++)
	  {
		  ob[i]=new Student();
		  name=in.next();
		  id=in.nextInt();
		  add=in.next();
		  
		  ob[i].setName(name);
		  ob[i].setID(id);
		  ob[i].setAddress(add);
	  }
	  
	  System.out.println("Students Information-");
	  for(i=0;i<2;i++)
	  {
		  
	    System.out.println(ob[i].getName());
	    System.out.println(ob[i].getID());
	    System.out.println(ob[i].getaddress());
	  }
	  
}
}
