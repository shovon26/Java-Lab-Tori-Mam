package PakPak;

public class Violin extends Instrument {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("play Violin");
		
	}

	@Override
	public void adjust() {
		// TODO Auto-generated method stub
		System.out.println("Adjus Violin");
		
	}
	
	public void compose() {
		System.out.println("Compose Violin");
	}

}
