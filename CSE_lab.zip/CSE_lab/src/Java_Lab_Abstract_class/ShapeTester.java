package Java_Lab_Abstract_class;
import java.util.Scanner;
public class ShapeTester {
   public static void main(String[] args) {
	   Scanner input=new Scanner(System.in);
	    
	   System.out.println("Enter the value of Heigth and width");
	   double height=input.nextDouble();
	   double width=input.nextDouble();
	   
	Rectangle ob1=new Rectangle(height,width);
	
	ob1.computeArea();
	ob1.displayShape();
    
	System.out.println("Enter the value of Length");
	double length=input.nextDouble();
	
    Square ob2=new Square(length);
     
    ob2.computeArea();
    ob2.displayShape();
}
}
