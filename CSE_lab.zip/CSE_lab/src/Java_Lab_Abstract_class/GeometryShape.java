package Java_Lab_Abstract_class;

public abstract class GeometryShape {
   
	public double area;
	public GeometryShape()
	{
		area=0;
	}
	
	public abstract void computeArea();
	public abstract void displayShape();
	
	void setArea(double x)
	{
		this.area=x;
	}
	
	double GetArea()
	{
		
		return this.area;
		//return "Var1 value="+this.var1+"::Var2 value"+this.var2;
	} 
}
