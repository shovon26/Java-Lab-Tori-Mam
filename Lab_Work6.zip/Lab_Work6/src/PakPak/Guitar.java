package PakPak;

public class Guitar extends Instrument {
   
	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Guitar");
		
	}

	@Override
	public void adjust() {
		// TODO Auto-generated method stub
		System.out.println("Purpose");
	}
	
	public void compose() {
		System.out.println("Compose Music");
	}
}
