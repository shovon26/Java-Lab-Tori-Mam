package Interface_pak;

public interface StInterfacee {
     
	public void setName(String s);
	public void setID(int id);
	public String getName();
	public int getID();
	
}
