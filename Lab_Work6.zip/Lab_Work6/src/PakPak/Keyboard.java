package PakPak;

public class Keyboard extends Instrument{

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Keyboard");
		
	}

	@Override
	public void adjust() {
		// TODO Auto-generated method stub
		System.out.println("Adjust keyboard");
		
	}
   
	public void compose() {
		System.out.println("Compose Keyboard");
	}
   
}
